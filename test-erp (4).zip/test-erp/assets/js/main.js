


$(document).ready(function() {
  var table = $('#dashboard_data_table').DataTable({
      pageLength: 14
      
  });
  
  var table = $('#dashboard_data_table1').DataTable({
    pageLength: 10
    
})
  
});


$("#menu-toggle").click(function(e) {
    e.preventDefault();
       var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
           $("#toggleIcon").toggleClass("bi bi-chevron-double-right bi bi-x-lg")
           $("#wrapper").toggleClass("toggled");
   
         if(isIE11){
             if($("#wrapper").hasClass("toggled")){
           $('#sidebar-wrapper').css("margin-left", "-200px")
         } else {
           $('#sidebar-wrapper').css("margin-left", "-250px")	
             }	 
       }
       });
       